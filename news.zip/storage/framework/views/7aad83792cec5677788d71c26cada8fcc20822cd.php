<?php $__env->startSection('content'); ?>

<div class="container">

	
	

	
	<div class="row">


		
		<div class="col-md-8">

		<?php $__currentLoopData = App\Category::whereNotNull('published_by')->orderBy('order_on_homepage')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php
			$latest_news = $category
							->news()
							->whereNotNull('published_by')
							->latest('news_datetime')
							->limit($category->news_on_homepage)
							->get();
			?>
		
		

			<div class="panel panel-success">
				<div class="panel-heading">
					<a href="<?php echo e(url('category/'.$category->id)); ?>">
						<h1 style="margin: 0; color:black;"><?php echo e($category->title); ?></h1>
					</a>
				</div>
				<div class="panel-body">
					

					<?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4">

						<a href="<?php echo e(url('news').'/'.$news->id); ?>">
							<img style="width: 100%;" src="<?php echo e(asset($news->image)); ?>">
							<h3><?php echo e($news->heading); ?></h3>
						</a>

						<p>
							<?php echo e(str_limit( $news->detail, 150, '...')); ?>

							<a href="<?php echo e(url('news').'/'.$news->id); ?>">بقیہ</a>
						</p>

						<small dir="ltr"><?php echo e(\Carbon\Carbon::parse($news->news_datetime)->format('d M Y h:i a')); ?></small>

					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>

		<div class="col-md-4">

     		<div class="panel panel-info">
				<div class="panel-heading">
					<a href="<?php echo e(url('articles')); ?>">
						<h1 style="margin: 0; color:black;">آرٹیکلز</h1>
					</a>
				</div>
				<div class="panel-body">
					
					<?php 

					$articles = DB::table('articles')
									->whereNotNull('published_by')
									->join('cms_users', 'cms_users.id', '=', 'articles.created_by')
									->select('cms_users.photo', 'articles.title', 'articles.detail', 'articles.article_datetime', 'cms_users.name', 'articles.id')
									->orderBy('article_datetime', 'desc')
									->limit(20)
									->get();

					 ?>

					<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row">
						<div class="col-md-8">
							<h1><?php echo e($article->title); ?></h1>

							<p>
								<?php echo e(str_limit( $article->detail, 150, '...')); ?>

								<a href="<?php echo e(url('articles').'/'.$article->id); ?>">بقیہ</a>
							</p>
							<br>
							<small><?php echo e($article->name); ?></small>
							<br>
							<small dir="ltr"><?php echo e(\Carbon\Carbon::parse($article->article_datetime)->format('d M Y')); ?></small>
						</div>
						<div class="col-md-4">
							<img style="width: 100%;" src="<?php echo e(asset($article->photo)); ?>">
						</div>
					</div>
					<hr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>

		

        </div>


	</div>
	



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>