<?php $__env->startSection('content'); ?>

    <div class="container">



	    	
    	<div class="row">

    		<h1>آرٹیکلز</h1>


    		<?php $__currentLoopData = $paginated_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<div class="col-md-3">

    			<a href="<?php echo e(url('articles').'/'.$article->id); ?>">
    				<img style="width: 100%;" src="<?php echo e(asset($article->author_photo)); ?>">
    				<h3><?php echo e($article->title); ?></h3>
    			</a>
    			
    			<p>
    				<?php echo e(str_limit( $article->detail, 150, '...')); ?>

    				<a href="<?php echo e(url('articles').'/'.$article->id); ?>">بقیہ</a>
    			</p>
    			
    			<small dir="ltr"><?php echo e(\Carbon\Carbon::parse($articles->article_datetime)->format('d M Y h:i a')); ?></small>

    		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    	</div>

    	<?php echo e($paginated_articles->links()); ?>

	    	

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>