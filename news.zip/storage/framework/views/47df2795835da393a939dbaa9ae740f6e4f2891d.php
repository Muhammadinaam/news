<?php $__env->startSection('content'); ?>

    <div class="container">



	    	
    	<div class="row">



    		<div class="col-md-12">

    			<div class="row">

                    <div class="col-md-2">
    				    <img style="width: 100%;" src="<?php echo e(asset($article->author_photo)); ?>">
                    </div>

                    <div class="col-md-10">
        				<h3><?php echo e($article->title); ?></h3>
                        <small dir="ltr"><?php echo e(\Carbon\Carbon::parse($article->article_datetime)->format('d M Y')); ?></small>
                    </div>
    			</div>
    			
    			<p>
    				<?php echo e($article->detail); ?>

    			</p>
    			
    			

    		</div>

           
    		

    	</div>

	    	

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>