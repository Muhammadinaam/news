<?php $__env->startSection('content'); ?>

    <div class="container">



	    	
    	<div class="row">

    		<h1><?php echo e($category->title); ?></h1>


    		<?php $__currentLoopData = $news_paginated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<div class="col-md-3">

    			<a href="<?php echo e(url('news').'/'.$news->id); ?>">
    				<img style="width: 100%;" src="<?php echo e(asset($news->image)); ?>">
    				<h3><?php echo e($news->heading); ?></h3>
    			</a>
    			
    			<p>
    				<?php echo e(str_limit( $news->detail, 150, '...')); ?>

    				<a href="<?php echo e(url('news').'/'.$news->id); ?>">بقیہ</a>
    			</p>
    			
    			<small dir="ltr"><?php echo e(\Carbon\Carbon::parse($news->news_datetime)->format('d M Y h:i a')); ?></small>

    		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    	</div>

    	<?php echo e($news_paginated->links()); ?>

	    	

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>